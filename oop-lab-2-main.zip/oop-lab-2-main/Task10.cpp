#include <iostream>
using namespace std;

int main()
{
    int a, b, c;
    cout << "Enter the dimensions for the 3d array: " << endl;
    cin >> a >> b >> c;
    int ***arr = new int **[a];
    for (int i = 0; i < a; i++)
    {
        arr[i] = new int *[b];
        for (int j = 0; j < b; j++)
        {
            arr[i][j] = new int[c];
        }
    }
    cout << "Enter the elements of the 3d array: " << endl;
    for (int i = 0; i < a; i++)
    {
        for (int j = 0; j < b; j++)
        {
            for (int k = 0; k < c; k++)
            {
                cin >> arr[i][j][k];
            }
        }
    }
    cout << "The elements of the 3d array are: " << endl;
    for (int i = 0; i < a; i++)
    {
        for (int j = 0; j < b; j++)
        {
            for (int k = 0; k < c; k++)
            {
                cout << arr[i][j][k] << " ";
            }
            cout << endl;
        }
        cout << endl;
    }
    for (int i = 0; i < a; i++)
    {
        for (int j = 0; j < b; j++)
        {
            delete[] arr[i][j];
        }
        delete[] arr[i];
    }
    delete[] arr;
}