#include <iostream>
using namespace std;

struct product{
    int productID;
    string name;
    int quantity;
    float price;
};
int main()
{
    int n;
    cout << "Enter the number of products: ";
    cin >> n;
  product* p = new product[n];
  for(int i=0;i<n;i++){
    cout<<"Product "<<i+1<<endl;
      cout << "Enter the product ID: ";
      cin >> p[i].productID;
      cout << "Enter the product name: ";
      cin >> p[i].name;
      cout << "Enter the quantity: ";
      cin >> p[i].quantity;
      cout << "Enter the price: ";
      cin >> p[i].price;
  }
  float totalInventory = 0;
  cout<<"Product Details"<<endl;
    for(int i=0;i<n;i++){
        cout<<"Product "<<i+1<<endl;
        cout << "Product Name: " << p[i].name << endl;
        cout << "Product ID: " << p[i].productID << endl;
        cout << "Quantity: " << p[i].quantity << endl;
        cout << "Price: " << p[i].price << endl;
        float total = p[i].quantity * p[i].price;
        cout << "Total: $ " << total << endl;
        totalInventory += total;
        cout<<"\n";
    }
    cout<<"\n";
    cout << "Total Inventory Value: $ " << totalInventory << endl;
    delete[] p;
}