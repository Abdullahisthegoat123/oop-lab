#include <iostream>
using namespace std;
struct student
{
    string name;
    int rollNumber;
    float marks[3];
};

int main()
{
    int n;
    cout << "Enter the number of students: ";
    cin >> n;
    student *s = new student[n];
    for (int i = 0; i < n; i++)
    {
        cout << "Enter Name of Student#"<<i+1<<": ";
        cin >> s[i].name;
        cout << "Enter Roll Number: ";
        cin >> s[i].rollNumber;
        cout << "Enter Marks of the three subjects: "<<endl;
        for (int j = 0; j < 3; j++)
        {
            cin >> s[i].marks[j];
        }
    }
    float sum = 0;
    cout << "Student details:" << endl;
    for (int i = 0; i < n; i++)
    {
        cout<<"Student#"<<i+1<<endl;
        cout << "Name: " << s[i].name << endl;
        cout << "Roll Number: " << s[i].rollNumber << endl;
        cout << "Marks of the three subjects: ";
        for (int j = 0; j < 3; j++)
        {
            cout << s[i].marks[j] << " ";
            sum += s[i].marks[j];
        }
        cout << endl;
        cout << "Average marks: " << sum / 3.0 << endl;
        sum = 0;
    }
    delete[] s;
}